const canvasSketch = require('canvas-sketch');
const math = require('canvas-sketch-util/math');
const random = require('canvas-sketch-util/random');

const settings = {
    dimensions: [1080, 1080]
};

let backgroundColor = 'white';
let lineColor = 'black';
let circleColor = 'black';

const sketch = () => {
    return ({ context, width, height }) => {
        context.fillStyle = backgroundColor;
        context.fillStyle = lineColor;

        //creating the line
        context.save();
        context.translate(450, 450);
        context.beginPath();
        context.rect(540, 540, 5, 5);
        context.fill();
        context.restore();

        //creating a circle
        // context.save();
        // context.translate(450, 450);
        // context.beginPath();
        // context.arc(100, 75, 50, 0, 2 * Math.PI);
        // context.strokeStyle = circleColor;
        // context.stroke();
        // context.restore();
        //end of the circle
    };
};



canvasSketch(sketch, settings);